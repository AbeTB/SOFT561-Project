#ifndef LCDControl_h
#define LCDControl_h

#include <LCD.h>
#include <LiquidCrystal.h>
#include <LiquidCrystal_I2C.h>
#include <Wire.h> 

class LCDControl
(
);

#endif