#include "motorControl.h"

const int pwmA  = 3;
const int pwmB  = 11;
const int brakeA  = 9;
const int brakeB  = 8;
int lSpeed;
int rSpeed;
int dSpeed;
int xPos;
int x2Pos;


void motorControl::motorSetup()
{
  pinMode(pwmA, OUTPUT);
  pinMode(pwmB, OUTPUT);
  pinMode(brakeA, OUTPUT);
  pinMode(brakeB, OUTPUT);
}

void motorControl::steerAngle()
{
  digitalWrite(6, HIGH);
  delay(250);
  digitalWrite(6, LOW);
  delay(250);  
}

void motorControl::rightTurn(int lSpeed)
{
  digitalWrite(brakeA, HIGH);
  digitalWrite(brakeB, LOW);
  analogWrite(pwmA, 0);
  analogWrite(pwmB, lSpeed); 
}

void motorControl::leftTurn(int rSpeed)
{
  digitalWrite(brakeA, LOW);
  digitalWrite(brakeB, HIGH);
  analogWrite(pwmA, rSpeed);
  analogWrite(pwmB, 0); 
}

void motorControl::brake()
{
  digitalWrite(brakeA, HIGH);
  digitalWrite(brakeB, HIGH);
  analogWrite(pwmA, 0);
  analogWrite(pwmB, 0); 
}

void motorControl::forwardDrive(int dSpeed)
{
  digitalWrite(brakeA, LOW);
  digitalWrite(brakeB, LOW);
  analogWrite(pwmA, dSpeed);
  analogWrite(pwmB, dSpeed); 
}

int motorControl::ReadPi()
{
  if (Serial.available())  {
    xPos = (Serial.read() - '0');  // convert the character '1'-'9' to decimal 1-9
    return xPos;
  }
}

void motorControl::FollowX(int xPos, int RunPwm)
{
    x2Pos = (xPos +1)*25;
  int xPosR = 250-((x2Pos-1)*2);
  int xPosL = x2Pos;
 
  if(xPos >= 6 and xPos < 10) //To the Right
  {
  analogWrite(pwmB, xPosL);
  analogWrite(pwmA, 0);
  
  digitalWrite(brakeA, LOW);
  digitalWrite(brakeB, LOW);
  }
    if(xPos <= 4 and xPos >= 0) //To the Left
    {
    analogWrite(pwmB, 0);
    analogWrite(pwmA, xPosR);
    
    digitalWrite(brakeA, LOW);
    digitalWrite(brakeB, LOW);
    }
    if (xPos = 5)
{
          analogWrite(pwmA, RunPwm);  //Pwm Based on distance
          analogWrite(pwmB, RunPwm);
          
          digitalWrite(brakeA, LOW);
          digitalWrite(brakeB, LOW);
} 
}


